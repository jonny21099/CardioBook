package com.example.jcmartin_cardiobook;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
//Used lab 2 and 3 as a foundation for this class
public class CustomList extends ArrayAdapter<heartData> {
    private ArrayList<heartData> records;
    private Context context;

    public CustomList(Context context, ArrayList<heartData> records){
        super(context, 0, records);
        this.records = records;
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //return super.getView(position, convertView, parent);
        View view = convertView;

        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.content, parent, false);
        }
        //set my varibales to the content.xml with the correct TextView
        heartData heart = records.get(position);
        TextView systolicRecord = view.findViewById(R.id.systolic_content);
        TextView diastolicRecord = view.findViewById(R.id.diastolic_content);
        TextView heartRate = view.findViewById(R.id.heart_rate_content);
        TextView dateRecord = view.findViewById(R.id.date_content);

        //sets the text inside the textview
        systolicRecord.setText(heart.getSystolic_record());
        diastolicRecord.setText(heart.getDiastolic_record());
        heartRate.setText(heart.getHeart_record());
        dateRecord.setText(heart.getDate_record());

        //I need to retreive the integer values from systolic pressure and diastolic pressure
        Integer systolicCheck = Integer.parseInt(heart.getSystolic_record());
        Integer diastolicCheck = Integer.parseInt(heart.getDiastolic_record());

        //if they are abnormal, change the text to red
        if(systolicCheck < 90 || systolicCheck > 140){
            systolicRecord.setTextColor(Color.RED);
        }
        //if they are normal, make the text gray
        else{
            systolicRecord.setTextColor(Color.GRAY);
        }
        if(diastolicCheck < 60 || diastolicCheck > 90){
            diastolicRecord.setTextColor(Color.RED);
        }
        else{
            diastolicRecord.setTextColor(Color.GRAY);
        }
        return view;
    }
}