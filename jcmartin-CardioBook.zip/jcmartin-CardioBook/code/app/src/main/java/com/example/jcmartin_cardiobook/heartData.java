package com.example.jcmartin_cardiobook;

//Used lab 2 and 3 as a foundation for this class
public class heartData {
    private String systolic_record;
    private String diastolic_record;
    private String heart_record;
    private String date_record;
    private String time_record;
    private String comment;

    heartData(String systolic_record, String diastolic_record, String heart_record, String date_record, String time_record, String comment) {
        this.systolic_record = systolic_record;
        this.diastolic_record = diastolic_record;
        this.heart_record = heart_record;
        this.date_record = date_record;
        this.time_record = time_record;
        this.comment = comment;
    }

    String getSystolic_record() {
        return this.systolic_record;
    }

    String getDiastolic_record() {
        return this.diastolic_record;
    }

    String getHeart_record() {
        return this.heart_record;
    }

    String getDate_record() {
        return this.date_record;
    }

    String getTime_record() {
        return this.time_record;
    }

    String getComment() {
        return this.comment;
    }

    public void setSystolic_record(String systolic_record) {
        this.systolic_record = systolic_record;
    }

    public void setDiastolic_record(String diastolic_record) {
        this.diastolic_record = diastolic_record;
    }

    public void setHeart_record(String heart_record) {
        this.heart_record = heart_record;
    }

    public void setDate_record(String date_record) {
        this.date_record = date_record;
    }

    public void setTime_record(String time_record) {
        this.time_record = time_record;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
