package com.example.jcmartin_cardiobook;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.util.ArrayList;

//Used lab 2 and 3 as a foundation for this class
//At First I tried to implement NumberPicker DatePicker and TimePicker and I really liked the idea, but I didn't know how to deal with the types, so i had to scratch
//that idea and change it to a complete different way of restrciting my user input
public class AddHeartFragment extends DialogFragment {
    private EditText systolicRecord;
    private EditText diastolicNum;
    private EditText heartNum;
    private EditText dateNum;
    private EditText timeNum;
    private EditText commentStore;
    private OnFragmentInteractionListener listener;
    private heartData heartStore;
    private ArrayList<heartData> heartDataList;

    public interface OnFragmentInteractionListener {
        void onOkPressed(heartData newHeart);
    }
    public AddHeartFragment(){
        //If adding a new measurement
    }
    //I need to pass myself the heartDataList because later I need to saveData
    public AddHeartFragment(heartData heart, ArrayList<heartData> heartDataList) {
        heartStore = heart;
        this.heartDataList = heartDataList;
    }

    @Override
    public void onAttach(Context context){
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            listener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        //this sets all my variables to the editText boxes
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.add_records_fragment_layout,null);
        systolicRecord = view.findViewById(R.id.systolic_editText);
        diastolicNum= view.findViewById(R.id.diastolic_editText);
        heartNum = view.findViewById(R.id.heart_editText);
        dateNum = view.findViewById(R.id.date_editText);
        timeNum = view.findViewById(R.id.time_editText);
        commentStore = view.findViewById(R.id.comment_edit);

        //this checks if we are editing or adding
        if(heartStore != null) {
            //if we are editing lets retain all the information first
            systolicRecord.setText(heartStore.getSystolic_record());
            diastolicNum.setText(heartStore.getDiastolic_record());
            heartNum.setText(heartStore.getHeart_record());
            dateNum.setText(heartStore.getDate_record());
            timeNum.setText(heartStore.getTime_record());
            commentStore.setText(heartStore.getComment());
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        return builder
                .setView(view)
                .setTitle("Add/Edit Measurement")
                .setNegativeButton("Cancel",null)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    //When you click the ok button my code checks alot of conditions, such as whether all the crucial information are all filled, else pop-up error
                    //for date and time I use regex to check the format and the range of the numbers
                    //and I also check if heratStore = null that means we are adding a new object, else we are editing, and at the end we need to save.
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String systolic_record = systolicRecord.getText().toString();
                        if(!(systolic_record.isEmpty())) {
                            Integer systolic = Integer.parseInt(systolic_record);
                            String diastolic_record = diastolicNum.getText().toString();
                            if (!(diastolic_record.isEmpty())) {
                                Integer diastolic = Integer.parseInt(diastolic_record);
                                String heartBeat_record = heartNum.getText().toString();
                                if (!(heartBeat_record.isEmpty())) {
                                    Integer heart = Integer.parseInt(heartBeat_record);
                                    String date_record = dateNum.getText().toString();
                                    if (date_record.matches("^\\d{4}-\\b(0[1-9]|1[0-2])\\b-\\b(0[1-9]|1[0-9]|2[0-9]|3[0-1])\\b")) {
                                        String time_record = timeNum.getText().toString();
                                        if (time_record.matches("\\b(0[0-9]|1[0-9]|2[0-3])\\b:\\b([0-5][0-9])\\b")) {
                                            String comment_record = commentStore.getText().toString();
                                            if (heartStore == null) {
                                                listener.onOkPressed(new heartData(systolic_record, diastolic_record, heartBeat_record, date_record, time_record, comment_record));
                                            } else {
                                                heartStore.setSystolic_record(systolic_record);
                                                heartStore.setDiastolic_record(diastolic_record);
                                                heartStore.setHeart_record(heartBeat_record);
                                                heartStore.setDate_record(date_record);
                                                heartStore.setTime_record(time_record);
                                                heartStore.setComment(comment_record);
                                                MainActivity.saveData(getContext(), heartDataList);
                                            }
                                        } else {
                                            Toast.makeText(getContext(), "Please enter a valid time.", Toast.LENGTH_SHORT).show();
                                        }
                                    } else {
                                        Toast.makeText(getContext(), "Please enter a valid date.", Toast.LENGTH_SHORT).show();
                                    }
                                } else {
                                    Toast.makeText(getContext(), "Please enter a valid heart rate.", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(getContext(), "Please enter a valid diastolic measurement.", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getContext(), "Please enter a valid systolic measurement.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).create();
    }


}

