Name = Jonathan Martins
CCID = jcmartin
 I did not collaborate with anyone, all my sources are labelled in my code as comment.