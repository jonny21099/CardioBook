package com.example.jcmartin_cardiobook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

//CITATIONS:

//1. Used codes and demos taught in both the classroom and the lab as a foundation for my code.
//2. Watched a few videos on YouTube produced by "Brad Teaches Code"
//playlist = "Android Studio Tutorials - Lets Build An App"
//    titles  : "Android Studio Tutorial - Lets Build An App 1 - Magic 8-Ball - Build Your First Android App"
//            : "Android Studio Tutorial - Lets Build An App 2 - To-do List App"
//            : "Android Studio Tutorial - Lets Build An App 3 - Basic Calculator - Part 1"
//            : "Android Studio Tutorial - Lets Build An App 4 - Basic Calculator - Part 2"
//    dates   : "April 11th, 2018"
//            : "April 13th, 2018"
//            : "May 22nd, 2018"
//            : "May 22nd, 2018"
//    URL     : https://www.youtube.com/watch?v=W2mZheKAAF4&list=PLlpyyl9hsy9YNuPF67YoRIWh7mq7YCmhg&index=2&t=0s
//            : https://www.youtube.com/watch?v=YmRPIGFftp0&list=PLlpyyl9hsy9YNuPF67YoRIWh7mq7YCmhg&index=3&t=0s
//            : https://www.youtube.com/watch?v=HrsZEZPXYVw&list=PLlpyyl9hsy9YNuPF67YoRIWh7mq7YCmhg&index=4&t=0s
//            : https://www.youtube.com/watch?v=mRk9ag9tJzw&list=PLlpyyl9hsy9YNuPF67YoRIWh7mq7YCmhg&index=5&t=0s
//3. Watched YouTube Video produced by "Coding in Flow"
//                            Title:  "How to Save an ArrayList of Custom Objects to SharedPreferences with Gson - Android Studio Tutorial"
//                            Date:  "November 6th, 2017"
//                            URL: https://www.youtube.com/watch?v=jcliHGR3CHo&t=357s




public class MainActivity extends AppCompatActivity implements AddHeartFragment.OnFragmentInteractionListener{
    //Declare the variables so I can reference them later
    ListView heartList;
    ArrayAdapter<heartData> heartAdapter;
    ArrayList<heartData> heartDataList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        heartList = findViewById(R.id.m_list);
        loadData();
        heartAdapter = new CustomList(this, heartDataList);
        heartList.setAdapter(heartAdapter);

        //initializing both my add button and my delete button

        final FloatingActionButton addHeartButton = findViewById(R.id.add_button);
        final FloatingActionButton deleteHeartButton = findViewById(R.id.delete_button);

        //if the add button is clicked

        addHeartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //if someone clicks the addHeartButton jump to my fragment class and show my diaglogbox
                new AddHeartFragment().show(getSupportFragmentManager(), "ADD_HEART");
            }
        });
        //if someone clicks any of the items displaying, then it will retreive the position of the item clicked, and it will call my fragment class and pass on the needed information
        heartList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                final heartData EditHeart = (heartData) heartList.getItemAtPosition(position);
                new AddHeartFragment(EditHeart, heartDataList).show(getSupportFragmentManager(), "EDIT_HEART");
            }
        });
        //if someone holds an item on the list, they can then delete the object
        //I was debating whether to do delete in the main menu or in the dialog popup, but I really like the idea of having two buttons on the main menu
        heartList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                final heartData DelHeart = (heartData) heartList.getItemAtPosition(position);
                deleteHeartButton.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        heartDataList.remove(DelHeart);
                        heartList.setAdapter(heartAdapter);
                        heartAdapter.notifyDataSetChanged();
                        //since I can't pass saveData into a onItemClickListener. object I have to make a method that does that.
                        notifyme(heartDataList);

                    }
                });
                return true;
            }
        });

    }
    //this method allows me to call saveData inside my onItemClick
    public void notifyme(ArrayList<heartData> heartDataList){
        MainActivity.saveData(this, heartDataList);
    }

    //Learned this from one of my citations, but i had to change the parameter and the private void to public static void because I need this in my addHeartFragment
    public static void saveData(Context context, ArrayList<heartData> heartDataList){
        SharedPreferences sharedPreferences = context.getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(heartDataList);
        editor.putString("list", json);
        editor.apply();
    }

    private void loadData(){
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("list",null);
        Type type = new TypeToken<ArrayList<heartData>>(){}.getType();
        heartDataList = gson.fromJson(json, type);
        if (heartDataList == null) {
            heartDataList = new ArrayList<>();
        }
    }
    //If someone clicks the add button this is called in the addHeartFragmnet class
    @Override
    public void onOkPressed(heartData newHeart) {
        heartAdapter.add(newHeart);
        saveData(this, heartDataList);
    }
}